/*
c++ resort.cpp -o resort  sims/util.o -lm

reads resort.dat and finds original pairings 

5
2 1 4 4
3 2 3 1
1 3 1 2
4 4 2 3
0 0 0 0

2 3 1 4 0 = was1
1 2 3 4 0 = now1
4 3 1 2 0 = now2
4 1 2 3 0 = was2

Link was1 through now[12] to was2 equivalent 

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
char	line[99];
FILE	*dat;
int	**pat;
int	n, in = 0;
	dat = fopen("resort.dat","r");
	fscanf(dat,"%d", &n);	// total number of sequences
	//Pi(n) Pt(sequences) NL 
	pat = new int* [n];
	FOR(i,n) pat[i] = new int[4];
	next_line(dat);
	while (1) // read sequence order
	{ int   io = read_line(dat,line);
		if (io <= 0) break;
		sscanf(line,"%d %d %d %d", pat[in]+0, pat[in]+1, pat[in]+2, pat[in]+3);
		in++;
	}
	in = 0; //count outgroup matches
	FOR(i,n) { int was1 = pat[i][0], now1 = pat[i][1];
		if (was1>0 && was1<n-1) continue;
		FOR(j,n) { int now2 = pat[j][2], was2 = pat[j][3];
			if (now1 == now2) {
				if (was1==was2) in++;
			}
		}
	}
	if (in < 2) exit(1); // outgroups don't match NL needs fixed for out>2
	FOR(i,n) { int was1 = pat[i][0], now1 = pat[i][1];
		FOR(j,n) { int now2 = pat[j][2], was2 = pat[j][3];
			if (now1 == now2) {
				printf("%d %d\n", was1,was2);
				break;
			}
		}
	}
}
