/*
c++ swaps.cpp -o swaps sims/util.o -lm

*/

#include "sims/util.hpp"

int array[10] = {0,1,2,3,4,5,6,7,8,9};

void swap(int x, int y){
int temp = array[x];
    array[x] = array[y];
    array[y] = temp;
    return;
}

void permute(int k,int size){
int i;
    if (k==0) {
        for (i=0; i<size; i++) printf("-%c", 'A'+array[i]);
	printf("  %f\n", drand48());
    } else {
        for (i=k-1; i>=0; i--){
            swap(i,k-1);
            permute(k-1,size);
            swap(i,k-1);
        }
    }
    return;
}

int main (int argc, char** argv) {
int	n;
long	seed = (long)time(0);
	srand48(seed);
    	sscanf(argv[1],"%d", &n);
    	permute(n,n);
}
