/*
c++ treswaps.cpp -o treswaps sims/util.o -lm

1 = file of trees, 2 = nseqs (not counting outgroups), 3 = num of trees, 4 = num of outroup pairs, 5 = max number to use (eg 100: 5=120, 6=720, 7=5040, ...)
NB only works up to 10 seqs (0-9)
*/

#include "sims/util.hpp"


int main (int argc, char** argv) {
FILE	*swp, *tre;
char	**swap, **tree, line[999];
int	nseqs, ntree, nswap, nout, max, n;
    	sscanf(argv[2],"%d", &nseqs);
    	sscanf(argv[3],"%d", &ntree);
    	sscanf(argv[4],"%d", &nout);
    	sscanf(argv[5],"%d", &max);
	// read the permutations into <swap>
	swap = new char*[max];
	FOR(i,max) swap[i] = new char[22];
	swp = fopen("swap.list","r");
	n = 0;
	DO{ int io = read_line(swp,line);
		if (io <= 0) break;
		strcpy(swap[n],line);
		n++;
		if (n==max) break;
	}
	nswap = n;
	fclose(swp);
	// read the list of trees int <tree>
	tree = new char*[ntree];
	FOR(i,ntree) tree[i] = new char[999];
	tre = fopen(argv[1],"r");
	n = 0;
	DO{ int io = read_line(tre,line);
		if (io <= 0) break;
		strcpy(tree[n],line);
		n++;
		if (n==ntree) break;
	}
	// substitute each seq num with its permutant
	swp = fopen("swap.dat","w");
	FOR(i,ntree) { char newt[999], news[999];
		FOR(j,nswap) { int len;
			strcpy(news,swap[j]);
			strcpy(newt,tree[i]);
			len = strlen(newt);
			printf("%s\n", newt); // print the original for appending to refs.dat
			n = 0;
			FOR(j,len) { char sat; int is;
				if (newt[j] != '-') continue;	// skip to Seq-0ID
				if (newt[j-3] != 'S') continue;	// skip outgroups (Top-, Bot-)
				sat = news[n*2+1];
				is = (int)(sat-'A')+nout;
				newt[j+3] = '0'+is;
				n++;
			}
			fprintf(swp,"%s\n", newt); // write the permuted trees into swap.dat
		}
	}
}

/*
echo $argv[2] seqs
cat $argv[1] | sed 's/Seq/seq/g' > infile # protect caps
# refs.dat is accummulated across both runs (later infile and infile2 > swap.dat )
home/swaps $argv[2] | sort -n -k2 > swap.list
if ( -e swap.dat ) rm swap.dat
foreach swap ( `head -$argv[4] swap.list | awk '{print $1}'` )
	cp infile tmp0
	# nums to letters
	foreach a ( `echo $swap | tr "-" " "` )
        	eval "cat tmp0 | sed 's/seq-00[1-9]/&$a/' | sed 's/[1-9]$a/$a/' > tmp1"
		mv tmp1 tmp0
	end
	# letters to nums (starting after Top outgroups)
	@ m = $argv[3] - 1
	foreach a ( A B C D E F G H I J )
		eval "grep -q $a tmp0"
		if ( $? == 1 ) break
		@ m++
        	eval "cat tmp0 | sed 's/seq-00$a/seq-00$m/' > tmp1"
		mv tmp1 tmp0
	end
	cat tmp0 | sed 's/seq/Seq/g' >> swap.dat # restore caps
	cat $argv[1] >> refs.dat # keep corresponding originals
end
#cat swap.dat
@ n = `cat swap.list | wc -l`
echo Up to $argv[4] of $n combinations used
*/
