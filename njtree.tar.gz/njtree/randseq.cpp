/*
c++ rand.cpp -o rand sims/util.o -lm

./rand (int)seed-helper (int)number-out (float)value-range

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
char	line[9999];
FILE	*seq = fopen(argv[1],"r");
long    seed = (long)time(0);
	srand48(seed);
	DO{ int io = read_line(seq,line);
		if (io<0) exit(1);
		FOR(i,io) {
			if (i>30) { char a;
				if (isalpha(line[i])) a = 'A'+(int)(drand48()*25.0);
				if (a=='B' || a=='J' || a=='O') a = 'A';
				if (a=='U' || a=='X' || a=='Z') a = 'D';
			}
			printf("%c", line[i]);
		} NL
	}
}
