/*
c++ score.cpp -o score sims/util.o -lm

arg: 1 = file, 2 = score cut

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
Pairs	*pairs[3];
float	pair1, pair2, score, *ave, **mat[3], **sat[3], **sum[3], sums[3];
int	m,n, got, nseqs, seq[11], cut;
char	line[99], name[11];
FILE	*dat = fopen(argv[1],"r");
float   scorecut, s, t;
int	tries = 5;
	sscanf(argv[2],"%f", &s);
	scorecut = s - NOISE;
	Pr(scorecut) NL
	DO
	{ char *c;
	  int   io = read_line(dat,line);
		if (io <= 0) break;
		if (line[3]=='n') { // name of organism and number of seqs.(RUNning ACRCH 3)
			c = strchr(line+8,' ');
			sscanf(c,"%d", &nseqs);
			*c = (char)0;
			strcpy(name,line+8);
			Ps(name) Pi(nseqs) NL
			ave = new float [nseqs];
			FOR(k,3) {
				mat[k] = new float*[nseqs];
				sat[k] = new float*[nseqs];
				sum[k] = new float*[nseqs];
				pairs[k] = new Pairs[nseqs];
				FOR(i,nseqs) {
					mat[k][i] = new float[nseqs];
					sat[k][i] = new float[nseqs];
					sum[k][i] = new float[nseqs];
					FOR(j,nseqs) mat[k][i][j] = sat[k][i][j] = sum[k][i][j] = 0.0;
				}
			}
			FOR(i,nseqs) ave[i] = 0.0;
			got = 0;
			continue;
		}
		if (line[0]=='R') { Pairs *p = pairs[0]; // RUN
			got++;
			Pi(got) NL
			FOR(i,3) { // loop over block pairs (0=0+1, 1=1+2, 2=2+0)
				io = read_line(dat,line);
				FOR(j,nseqs) { int a,b; // read along sequence pairings ( a = b )*nseqs
					c = strchr(line,'=');
					sscanf(c-4,"%d", &a);
					sscanf(c+1,"%d", &b);
					p[j].a = a; p[j].b = b;
					*c = ' ';
				}
				c = strchr(line,'=');
				sscanf(c+1,"%f", &score);
				Pr(score) NL
				FOR(j,nseqs) { // sum scores over cutoff
					if (score > scorecut) mat[i][p[j].a][p[j].b] += score;
				}
			}
		}
	}
	NL
	m = nseqs;
	// then like pairup.cpp but without the outgroups
	FOR(shake,tries) { // randomised tries (maybe a small shake may hit a cyclic braid)
		score = 0.0;
		NL
		Pt(----------------------------) NL
		Pi(shake) NL NL
		FOR(k,3) {
			// for each block put the seq/seq distances (+rand) into <sat>
			t = 0.0; // holds the total sat matrix sum
			FOR(i,m) {
				FOR(j,m) { float d = 0.1;
					sat[k][i][j] = mat[k][i][j] + d*drand48();
					printf("%8.3f ", sat[k][i][j]);
					t += sat[k][i][j];
				} NL
			} NL
			s = 0.0; // s holds the selected pair sum
			pairup(sat[k],m,pairs[k]);
			FOR(i,m) { int a = pairs[k][i].a, b = pairs[k][i].b;
				Pi(a) Pi(b) Pr(pairs[k][i].s) NL
				s += pairs[k][i].s;
			} NL
			s /= t; // score of selected pairs normalised by total score (1=perfect small=bad)
			FOR(i,m) pairs[k][i].s *= s; // applied to selections
			score += s;
		}
		Pt(Normalised) Pr(score) NL
		NL
		Pt(Individual) NL
		FOR(i,m)
		{ int	a0 =  pairs[0][i].a, b0 = pairs[0][i].b,
			a1 =  pairs[1][i].a, b1 = pairs[1][i].b,
			a2 =  pairs[2][i].a, b2 = pairs[2][i].b;
			printf(" %d %d - %d %d - %d %d\n", a0,b0,a1,b1,a2,b2);
		} NL
		// trace path and accumulate pairs in sum for consensus
		FOR(k,3) FOR(i,m) FOR(j,m) sum[k][i][j] = 0.0;
		Pt(Chainned) NL
		FOR(i,m) // for each A-B link
		{ int	a0 =  pairs[0][i].a, b0 = pairs[0][i].b;
			FOR(j,m) // for each B-C link
			{ int	a1 =  pairs[1][j].a, b1 = pairs[1][j].b;
				if (b0 != a1) continue;
				FOR(k,m) // for each C-A link
				{ int	a2 =  pairs[2][k].a, b2 = pairs[2][k].b;
					if (b1 != a2) continue;
					if (a0==b2) s = 10.0; else s = 0.1; // bonus for cyclic
					sum[0][a0][b0] += pairs[0][i].s * s;
					sum[1][a1][b1] += pairs[1][j].s * s;
					sum[2][a2][b2] += pairs[2][k].s * s;
					printf(" %d %d = %d %d = %d %d ", a0,b0,a1,b1,a2,b2);
					if (s > 1.0) Pt(cyclic) NL
				}
			}
		}
	}
	NL
	Pt(============================) NL
	Pt(Summed pairs) NL
	FOR(k,3) { NL
		if (k==0) { Pt(Blocks 0+1) NL }
		if (k==1) { Pt(Blocks 1+2) NL }
		if (k==2) { Pt(Blocks 2+0) NL }
		FOR(i,m) {
			FOR(j,m) printf("%7.3f ", sum[k][i][j]/(float)tries); NL
		}
		score = 0.0;
		pairup(sum[k],m,pairs[k]);
		if (k==0) Pt(SUM 0+1)
		if (k==1) Pt(SUM 1+2)
		if (k==2) Pt(SUM 2+0)
		FOR(i,m) { int a = pairs[k][i].a, b = pairs[k][i].b;
			printf("%2d =%2d  ", a,b);
			score += pairs[k][i].s;
		}
		score *= 0.01;
		Pr(score) NL 
		sums[k] = score;
	} NL
	score = 0.0;
	pair1 = pair2 = -1.0;
	cut = sort3min(sums[0],sums[1],sums[2]);
	// cut is the weakest link, so skip
	FOR(i,3) { int hit = 0;
		if (i==cut-1) continue;
		FOR(j,nseqs) { int a = pairs[i][j].a+1, b = pairs[i][j].b+1;
			if (i==0) printf("prot1.seq%d=prot2.seq%d   ", a,b);
			if (i==1) printf("prot2.seq%d=prot3.seq%d   ", a,b);
			if (i==2) printf("prot3.seq%d=prot1.seq%d   ", a,b);
			if (a==b) hit++;
		}
		Pr(sums[i]) Pi(hit) NL
		score += (float)hit;
		if (pair1 < 0.0) pair1 = sums[i]; else pair2 = sums[i];
	}
	if ( cut == 0 ) exit(1); // two are 0 (?) so don't print score
	score = 100.0*score/(float)(nseqs*2);
	Pr(score) Pr(pair1) Pr(pair2) NL NL
}
