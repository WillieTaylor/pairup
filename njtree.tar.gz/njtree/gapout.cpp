/*
c++ gapout.cpp -o gapout sims/util.o -lm

strips gaps from block[123].tmp (one line format)

1 = file, 2 = cutoff fraction, 3 = seed help (-ve = flag for random seqs)

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
char	seqs[22][2222];
FILE	*seq = fopen(argv[1],"r");
int	rand, len, n;
long    seed = (long)time(0);
	sscanf(argv[3],"%d", &rand);
	srand48(seed+rand);
	n = 1; // keep 0 for io mark
	DO{ int io = read_line(seq,seqs[n]);
		if (io<0) break;
		len = io;
		n++;
	}
	n--;
	//Pi(n) Pi(len) NL
	FOR(i,len) { int gaps = 0;
		seqs[0][i] = ' ';
		if (i<10) continue; // don't mark title
		FIR(j,n) {
			if (seqs[j][i]=='-') gaps++;
		}							// skip
		if (argv[2][0]=='0' && gaps==n-1) seqs[0][i] = 'x';	// fully gapped
		if (argv[2][0]=='1' && gaps>0) seqs[0][i] = 'x';	// any gap
		if (argv[2][0]=='2' && gaps>n/2) seqs[0][i] = 'x';	// half gapped
		if (argv[2][0]=='3' && gaps>n/3) seqs[0][i] = 'x';	// third gapped
		if (argv[2][0]=='4' && gaps>n/4) seqs[0][i] = 'x';	// quarter gapped
	}
	FIR(i,n) {
		FOR(j,len) {
			if (seqs[0][j]=='x') continue;
			if (j>10 && rand<0) { char a = seqs[i][j];
				if (isalpha(a)) a = 'A'+(int)(drand48()*25.0); // pick a random letter
				if (a=='B' || a=='J' || a=='O') a = 'A';
				if (a=='U' || a=='X' || a=='Z') a = 'D';
				seqs[i][j] = a;
			}
			printf("%c", seqs[i][j]);
		} NL
	}
}
