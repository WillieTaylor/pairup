/*
c++ braid.cpp -o braid sims/util.o -lm

reads blocks of sequences from the same species from different different proteins (in block[123].seq)
and matchs up the best order relative to two outlying species (top and bottom of block[123].seq)

argv[1] = seed addition (in case run more than once in the same second)
argv[2] = nout = number of +/- outgroups

*/

#include "sims/util.hpp"

#define SCORE 1 // 0 = id, 1 = md
#define NACID 30
#define PATHS 33
#define RAND 999

#define BLOCKS 3
#define MAXTIT 33
#define MAXSEQ 333
#define MAXLEN 3333

float seqd ( char**, int, int, int, int );
void  matin ();

int	seqmat[NACID][NACID];

int main (int argc, char** argv) {
char	line[9999], ***seqs, ***code;
FILE	*seq, *dat;
int	slen, seqlen[BLOCKS];
int	in[BLOCKS], pn[BLOCKS];
float	**mat, **rat, score, **dout;
int	**pat, ntry, m,n, nout;
long	seed = (long)time(0);
	sscanf(argv[1],"%d", &ntry);
	seed += ntry;
	if (ntry < 0) { // fix seed for testing
		ntry = -ntry;
		seed = ntry;
	}
	Pi(seed) NL
	srand48(seed);
	sscanf(argv[2],"%d", &nout);
	Pi(nout) NL
	code = new char**[BLOCKS];
	seqs = new char**[BLOCKS];
	dout = new float*[3];
	FOR(i,BLOCKS) // for each block of paralogs (with outgroups at 0,1,.. and ...,n-2,n-1)
	{ float dave;
		code[i] = new char*[MAXSEQ];
		seqs[i] = new char*[MAXSEQ];
		in[i] = 0;
		sprintf(line,"block%d.seq", i+1);
		seq = fopen(line,"r");
		DO{ int io = read_line(seq,line);
			if (io <= 0 ) break;
			n = in[i];
			if (line[0]=='>') {
				*(strchr(line,'_')) = (char)0;
				m = strlen(line);
				if (m > MAXTIT) m = MAXTIT;
				code[i][n] = new char[m+1];
				strcpy(code[i][n],line);
			} else {
				m = io;
				if (m > MAXLEN) m = MAXLEN;
				seqs[i][n] = new char[m+1];
				strncpy(seqs[i][n],line,m);
				in[i]++;
			}
			if (in[i] == MAXSEQ) break;
		}	
		fclose(seq);
		Pi(i) Pi(in[i]) Pi(m) NL
		slen = seqlen[i] = m;
		n = in[i];
		mat = new float*[n]; // similarity matrix
		rat = new float*[n]; // randomised version
		pat = new int*[n];   // pointers for sort()
		// read the distance matrix (from protdist)
		sprintf(line,"block%d.dat", i+1);
		dat = fopen(line,"r");
		FOR(j,n) { int io;
			mat[j] = new float[n];
			rat[j] = new float[n];
			pat[j] = new int[n];
			FOR(k,n) { float d;
				io = read_line(dat,line);
				if (io <= 0 ) break;
				sscanf(line,"%f", &d);
				mat[j][k] = d;
			}
			if (io <= 0 ) break;
		}
		fclose(dat);
		// rescale distances to inter-outgroup average
		dout[i] = new float[nout*nout*2];
		m = 0;
		dave = 0.0;
		FOR(j,n) {
			FOR(k,n) { float d = mat[j][k];
				if (mat[j][k] != mat[j][k]) {
					Pt(Dist matrix is not symmetric)
					Pi(i) Pi(j) Pi(k) Pr(mat[j][k]) Pr(mat[j][k]) NL
					exit(1);
				}
				if (j==k && d!=0.0) {
					Pt(Dist matrix diagonal is not zero)
					Pi(i) Pi(j) Pr(mat[j][k]) NL
					exit(1);
				}
				if (k>=j) continue;
				if (j>=nout && j<n-nout) continue;
				if (k>=nout && k<n-nout) continue;
				// sum only out/out-group distances
				dave += d;
				dout[i][m] = d;
				m++;
			}
		}
		// take average over the <m> pairs
		dave /= (float)m;
		// rescale all distances and print in format for project() and matchup() = i j d w
		sprintf(line,"dists%d.dat", i+1);
		dat = fopen(line,"w");
		FOR(j,n) { float d, w=1.0;
			FOR(k,n) { // set the scale of the outgroups average to 10
				d = 10.0*mat[j][k]/dave;
				mat[j][k] = d;
				printf("%5.1f ", d);
				fprintf(dat,"%5d %5d   %f %f\n", j,k, d,w);
			} NL
		} NL
		fclose(dat);
	}
	// <dout> holds the distance between outgroups
	score = 0.0;
	FOR(i,m) { float d; 
		d = dout[0][i] - dout[1][i]; score += d*d;
		d = dout[1][i] - dout[2][i]; score += d*d;
		d = dout[0][i] - dout[2][i]; score += d*d;
	}
	score = sqrt(score/(m*3));
	// <score> is the RMSD between equivalent outgroup pairs
	Pr(score) NL
	// the score is used to find similar outgroups to use for matching in matchup()
}

float seqd ( char **seqs, int i, int j, int len, int mat ) {
// score two sequences i and j over their length: id = 10 + seqmat[][] if mat==1
float	score = 0;
int	n = 0;
	FOR(l,len)
	{ char  si = toupper(seqs[i][l]),
		sj = toupper(seqs[j][l]);
	  int	a, b;
		if (si<'A' || si>'Z') continue;	
		if (sj<'A' || sj>'Z') continue;	
		a = (int)(si-'A'),
		b = (int)(sj-'A');
		if (mat < 0) { // sum differrence
			if (seqs[i][l]!=seqs[j][l]) score += 1.0;
		} else { // similarity
			if (mat==1) score += seqmat[a][b];
			if (seqs[i][l]==seqs[j][l]) score += 10.0;
		}
		n++;
	}
	score = score/sqrt((float)n);
	return score;
}

void matin() {
/*
Mutation Data Matrix (120 PAMs) + 8
*/
int	mat[529] = {
 3,-3,-1, 0,-3,-1, 0, 1,-3,-1,-3,-2,-2,-4, 1, 1, 1,-7,-4, 0, 0,-1,-1,
-3, 6,-1,-3,-4, 1,-3,-4, 1,-2,-4, 2,-1,-5,-1,-1,-2, 1,-5,-3,-2,-1,-2,
-1,-1, 4, 2,-5, 0, 1, 0, 2,-2,-4, 1,-3,-4,-2, 1, 0,-4,-2,-3, 3, 0,-1,
 0,-3, 2, 5,-7, 1, 3, 0, 0,-3,-5,-1,-4,-7,-3, 0,-1,-8,-5,-3, 4, 3,-2,
-3,-4,-5,-7, 9,-7,-7,-4,-4,-3,-7,-7,-6,-6,-4, 0,-3,-8,-1,-3,-6,-7,-4,
-1, 1, 0, 1,-7, 6, 2,-3, 3,-3,-2, 0,-1,-6, 0,-2,-2,-6,-5,-3, 0, 4,-1,
 0,-3, 1, 3,-7, 2, 5,-1,-1,-3,-4,-1,-3,-7,-2,-1,-2,-8,-5,-3, 3, 4,-1,
 1,-4, 0, 0,-4,-3,-1, 5,-4,-4,-5,-3,-4,-5,-2, 1,-1,-8,-6,-2, 0,-2,-2,
-3, 1, 2, 0,-4, 3,-1,-4, 7,-4,-3,-2,-4,-3,-1,-2,-3,-3,-1,-3, 1, 1,-2,
-1,-2,-2,-3,-3,-3,-3,-4,-4, 6, 1,-3, 1, 0,-3,-2, 0,-6,-2, 3,-3,-3,-1,
-3,-4,-4,-5,-7,-2,-4,-5,-3, 1, 5,-4, 3, 0,-3,-4,-3,-3,-2, 1,-4,-3,-2,
-2, 2, 1,-1,-7, 0,-1,-3,-2,-3,-4, 5, 0,-7,-2,-1,-1,-5,-5,-4, 0,-1,-2,
-2,-1,-3,-4,-6,-1,-3,-4,-4, 1, 3, 0, 8,-1,-3,-2,-1,-6,-4, 1,-4,-2,-2,
-4,-5,-4,-7,-6,-6,-7,-5,-3, 0, 0,-7,-1, 8,-5,-3,-4,-1, 4,-3,-5,-6,-3,
 1,-1,-2,-3,-4, 0,-2,-2,-1,-3,-3,-2,-3,-5, 6, 1,-1,-7,-6,-2,-2,-1,-2,
 1,-1, 1, 0, 0,-2,-1, 1,-2,-2,-4,-1,-2,-3, 1, 3, 2,-2,-3,-2, 0,-1,-1,
 1,-2, 0,-1,-3,-2,-2,-1,-3, 0,-3,-1,-1,-4,-1, 2, 4,-6,-3, 0, 0,-2,-1,
-7, 1,-4,-8,-8,-6,-8,-8,-3,-6,-3,-5,-6,-1,-7,-2,-6,12,-2,-8,-6,-7,-5,
-4,-5,-2,-5,-1,-5,-5,-6,-1,-2,-2,-5,-4, 4,-6,-3,-3,-2, 8,-3,-3,-5,-3,
 0,-3,-3,-3,-3,-3,-3,-2,-3, 3, 1,-4, 1,-3,-2,-2, 0,-8,-3, 5,-3,-3,-1,
 0,-2, 3, 4,-6, 0, 3, 0, 1,-3,-4, 0,-4,-5,-2, 0, 0,-6,-3,-3, 4, 2,-1,
-1,-1, 0, 3,-7, 4, 4,-2, 1,-3,-3,-1,-2,-6,-1,-1,-2,-7,-5,-3, 2, 4,-1,
-1,-2,-1,-2,-4,-1,-1,-2,-2,-1,-2,-2,-2,-3,-2,-1,-1,-5,-3,-1,-1,-1,-2
};
        int     n, i, j, m = 8;
        char    acid[24], c;
	strcpy(acid,"ARNDCQEGHILKMFPSTWYVBZX");
        printf("%s\n",acid);
        printf("matrix constant = %d\n",m);
	for (i=0; i<NACID; i++) for (j=0; j<NACID; j++) seqmat[i][j] = m;
	n = 0;
        for (i = 0; acid[i]; i++ )
        {       int ai = acid[i]-'A';
        	for (j = 0; acid[j]; j++ )
                {       int aj = acid[j]-'A';
                        seqmat[ai][aj] = mat[n] + m;
			n++;
                }
        }
}
