/*
c++ blocks.cpp -o blocks sims/util.o -lm

*/

#include "sims/util.hpp"

#define PATHS 33
#define RAND 999

#define BLOCKS 3
#define MAXTIT 33
#define MAXSEQ 333
#define MAXLEN 3333

typedef struct {
int	a, b, c;
float	s;
} Blink;
Blink blink;

typedef struct {
int	*away, a;
int	*back, b;
} Path;

float seqd ( char**, int, int, int );
void trace ( Path*, int, int**, int, int );
void linkup ( Pairs***, int** );

int main (int argc, char** argv) {
Pairs	***pairs; // holds (sorted) list of paths for each pair of blocks
float	***dn = new float**[BLOCKS]; // holds scores between adjacent sequences on the path
int	**plist = new int*[BLOCKS]; // holds list of paths
char	line[9999], ***seqs,
	code[BLOCKS][MAXSEQ][MAXTIT+1];
FILE	*seq, out;
int	in[BLOCKS], pn[BLOCKS];
Path	path[BLOCKS][PATHS];
int	patn[BLOCKS][PATHS];
float	**mat, score;
int	**pat, m,n;
int	best, bet, len, have;
long	seed = (long)time(0);
	Pi(seed) NL
	//seed=1;
	srand48(seed);
	seqs = new char**[BLOCKS];
	FOR(i,BLOCKS) {
		seqs[i] = new char*[MAXSEQ];
		in[i] = 0;
		sprintf(line,"frame%d.seq", i+1);
		seq = fopen(line,"r");
		DO{ int io = read_line(seq,line);
			if (io <= 0 ) break;
			if (line[0]=='>') {
				if (io > MAXTIT) io = MAXTIT;
				*(strchr(line,'_')) = (char)0;
				strncpy(code[i][in[i]],line,io);
			} else {
				m = io; n = in[i];
				if (m > MAXLEN) m = MAXLEN;
				seqs[i][n] = new char[m+1];
				strncpy(seqs[i][n],line,m);
				in[i]++;
			}
			if (in[i] == MAXSEQ) break;
		}	
		fclose(seq);
		Pi(i) Pi(in[i]) Pi(m) NL
		n = in[i];
		mat = new float*[n];
		pat = new int*[n];
		// fill similarity matrix
		FOR(j,n) {
			mat[j] = new float[n];
			pat[j] = new int[n];
			FOR(k,n) {
				if (k>j) continue;
				score = seqd(seqs[i],j,k,m);
				if (j==k) score += 100.0;
				mat[j][k] = mat[k][j] = score;
			}
		}
		FOR(j,n) {
			FOR(k,n) printf("%5.1f ", mat[j][k]); NL
		} NL
		// sort neighbours and trace 0-->n-1-->0 path
		FOR(p,PATHS) {
			FOR(j,n) {
				sort(mat[j],pat[j],n);
				FOR(k,n) printf("%d=%5.1f ", pat[j][k], mat[j][pat[j][k]]); NL
			} NL
			path[i][p].away = new int[n]; path[i][p].a = 0;
			path[i][p].back = new int[n]; path[i][p].b = 0;
			Pt(PATH)
			trace(path[i]+p,0,pat,n,1);
			FOR(k,n) {
				pat[k][0] = 1; // flag as unused again
				FOR(l,n) {
					if (mat[k][l] < 1.0) mat[k][l] = 1.0;
					if (k==l) continue;
					mat[k][l] += (drand48()-0.5)*RAND/mat[k][k];
				}
			}
			mat[0][n-1] -= 1.0;
			mat[n-1][0] -= 1.0;
			NL NL
		}
		/*
		FOR(p,PATHS) { int a = path[i][p].a, b = path[i][p].b;
			printf("path %d %2d = ", i,a);
			FOR(k,a) printf("%2d",path[i][p].away[k]); NL
			printf("path %d %2d = ", i,b);
			FOR(k,b) printf("%2d",path[i][p].back[b-k-1]); NL
		}
		*/
	}
	n = 9999;
	FOR(i,BLOCKS) if (in[i] < n) n = in[i];
	Pi(n) NL
	best = len = 0;
	RIF(pathlen,n) { int hit[BLOCKS], got = 0;
		FOR(i,BLOCKS) {
			hit[i] = 0;
			FOR(p,PATHS) { int a = path[i][p].a, b = path[i][p].b;
				if ( a==pathlen ) {
					//printf("Path %d %2d = ", i,a);
					//FOR(k,a) printf("%2d",path[i][p].away[k]); NL
					hit[i]++;
				}
				if ( b==pathlen ) {
					//printf("Path %d %2d = ", i,b);
					//ROF(k,b) printf("%2d",path[i][p].back[k]); NL
					hit[i]++;
				}
			}
		}
		got = 9999;
		FOR(i,BLOCKS) if (hit[i] < got) got = hit[i];
		Pi(pathlen) Pi(got) NL
		bet = pathlen*pathlen*got;
		if (bet > best) {
			best = bet; len = pathlen; have = got;
		}
	}
	if (best==0) { Pt(No common paths) NL exit(1); }
	Pi(len) Pt(is best path length) NL
	Pi(have) Pt(common paths) NL
	if ( have < 2 ) { Pt(Not enough paths) NL exit(1); }
	// compile a list of unique paths with length <len> in plist
	FOR(i,BLOCKS) { int *pathij = new int[len];
		pn[i] = 0;
		plist[i] = new int[PATHS*2];
		F0R(j,PATHS) { int a = path[i][j].a, b = path[i][j].b;
			if ( a==len ) plist[i][pn[i]++] =  j+1; // outward path
			if ( b==len ) plist[i][pn[i]++] = -j-1; //  return path 
		} // NB needs +/-1 to discriminate +0 and -0 (+/-1 reversed below)
		Pi(i) Pi(pn[i]) Pt(paths) NL
		FOR(j,pn[i]) { int pij = plist[i][j]; int *p; // for each path
			if (pij==0) continue; // seen
			if (pij > 0) {
				p = path[i][ pij-1].away;
				FOR(k,len) pathij[k] = p[k];
			}
			if (pij < 0) {
				p = path[i][-pij-1].back;
				FOR(k,len) pathij[k] = p[len-k-1];
			}
			// Pi(j) Pi(pij) Pt(path =) FOR(k,len) printf("%d ",pathij[k]); NL
			// check if seen already
			FOR(k,pn[i]) { int pik = plist[i][k]; // for each path held
				if (k <= j) continue;
				if (pik==0) continue;
				n = 0;
				if (pik > 0) {
					FOR(l,len) { //printf("%d ", path[i][ pik-1].away[l]);
						if (path[i][ pik-1].away[l] == pathij[l]) n++;
					}
				}
				if (pik < 0) {
					FOR(l,len) { //printf("%d ", path[i][-pik-1].back[l]);
						if (path[i][-pik-1].back[l] == pathij[len-l-1]) n++;
					}
				}
				if (n==len) plist[i][k] = 0; // flag as already seen
			}
		}
		// remove redundant entries
		n = 0;
		FOR(j,pn[i]) { int pij = plist[i][j];
			if (pij==0) continue;
			plist[i][n] = plist[i][j];
			if (pij < 0) { int *p = path[i][-pij-1].back; // reverse back path
				FOR(k,len) pathij[k] = p[len-k-1];
				FOR(k,len) p[k] = pathij[k];
			}
			n++;
		} 
		pn[i] = n;
		Pi(n) Pt(paths left) NL
		// score adjacent entries
		dn[i] = new float*[pn[i]];
		FOR(j,pn[i]) { int *p, pij = plist[i][j];
			dn[i][j] = new float[len];
			if (pij > 0) p = path[i][ pij-1].away;
			if (pij < 0) p = path[i][-pij-1].back;
			FIR(k,len-1) { int s1 = p[k-1], s2 = p[k];
				dn[i][j][k-1] = seqd(seqs[i],s1,s2,m);
			}
		}
	}
	pairs = new Pairs**[BLOCKS];
	FOR(a,BLOCKS) { // loop over pairs of blocks
		pairs[a] = new Pairs*[BLOCKS];
		FOR(b,BLOCKS) {
			if (b <= a) continue;
			pairs[a][b] = new Pairs[pn[a]*pn[b]];
			//Pi(a) Pt(with) Pi(b) NL
			n = 0;
			FOR(i,pn[a]) { int *p, pi = plist[a][i];
				if (pi==0) { Pt(zero path) Pi(i) NL exit(1); }
				if (pi > 0) p = path[a][ pi-1].away;
				if (pi < 0) p = path[a][-pi-1].back;
				FOR(j,pn[b]) { int *q, qi = plist[b][j];
					if (qi==0) { Pt(zero path) Pi(j) NL exit(1); }
					if (qi > 0) q = path[b][ qi-1].away;
					if (qi < 0) q = path[b][-qi-1].back;
					/*
					Pi(i) Pi(j) NL
					Pt(P) FOR(k,len-1) printf("%3d %5.1f ", p[k],dn[a][i][k]);
					printf("%3d\n", p[len-1]);
					Pt(Q) FOR(k,len-1) printf("%3d %5.1f ", q[k],dn[b][j][k]);
					printf("%3d\n", q[len-1]);
					*/
					score = 0.0;
					FOR(k,len-1) { float d = dn[a][i][k] - dn[b][j][k];
						d *= d;
						if (k==0 || k==len-1) d = log(d); // damp ends
						score += d;
					}
					score = sqrt(score);
					// Pr(score) NL
					pairs[a][b][n].a = i;
					pairs[a][b][n].b = j;
					pairs[a][b][n].c = '-';
					pairs[a][b][n].s = score;
					n++;
				} // NL
			}
			pat[a][b] = n; // reuse pat[][] to count pairs
		}
	}
	FOR(a,BLOCKS) { // loop over pairs of blocks and sort paths by score
		FOR(b,BLOCKS) { Pairs *p;
			if (b <= a) continue;
			n = pat[a][b];
			p = pairs[a][b];
			sort(p,n);
			FOR(i,n) {
				if (plist[a][p[i].a]==0 || plist[b][p[i].b]==0) { 
					Pi(a) Pt(with) Pi(b) NL
					Pi(p[i].a) Pi(p[i].b) Pr(p[i].s) NL
					Pi(plist[a][p[i].a]) Pi(plist[b][p[i].b]) NL
				}
			}
		}
	}
	linkup(pairs,pat);
	Pi(blink.a) Pi(blink.b) Pi(blink.c) NL
	Pi(pairs[0][1][blink.a].a) Pi(pairs[0][1][blink.a].b) Pr(pairs[0][1][blink.a].s) NL
	Pi(pairs[1][2][blink.b].a) Pi(pairs[1][2][blink.b].b) Pr(pairs[1][2][blink.b].s) NL
	Pi(pairs[0][2][blink.c].a) Pi(pairs[0][2][blink.c].b) Pr(pairs[0][2][blink.c].s) NL
	{ int	ba = blink.a, bb = blink.b, bc = blink.c,
		// b[abc] = position in lists of pairs, giving p[abc][ab] = matched path pair
		paa = pairs[0][1][ba].a, pab = pairs[0][1][ba].b,
		pba = pairs[1][2][bb].a, pbb = pairs[1][2][bb].b,
		pca = pairs[0][2][bc].b, pcb = pairs[0][2][bc].a, // NB: a/b swap
		// from p[abc][ab] get the path from its plist[]
		plaa = plist[0][paa], plab = plist[1][pab],
		plba = plist[1][pba], plbb = plist[2][pbb],
		plca = plist[2][pca], plcb = plist[0][pcb];
		if (plaa*plab*plba*plbb*plca*plcb == 0) {
			Pt(Zero path) NL 
			Pi(paa) Pi(pab) Pi(plaa) Pi(plab) NL
			Pi(pba) Pi(pbb) Pi(plba) Pi(plbb) NL
			Pi(pca) Pi(pcb) Pi(plca) Pi(plcb) NL
			exit(1);
		}
		FOR(l,len) { int aa,ba,ca, ab,bb,cb;
			if (plaa > 0) aa = path[0][ plaa-1].away[l];
			if (plaa < 0) aa = path[0][-plaa-1].back[l];
			if (plba > 0) ba = path[1][ plba-1].away[l];
			if (plba < 0) ba = path[1][-plba-1].back[l];
			if (plca > 0) ca = path[2][ plca-1].away[l];
			if (plca < 0) ca = path[2][-plca-1].back[l];
			// NB: block for [abc]b shifts by 1
			if (plab > 0) ab = path[1][ plab-1].away[l];
			if (plab < 0) ab = path[1][-plab-1].back[l];
			if (plbb > 0) bb = path[2][ plbb-1].away[l];
			if (plbb < 0) bb = path[2][-plbb-1].back[l];
			if (plcb > 0) cb = path[0][ plcb-1].away[l];
			if (plcb < 0) cb = path[0][-plcb-1].back[l];
			printf("%d-%d %d-%d %d-%d  ", aa,ab, ba,bb, ca,cb);
			printf("%s %s %s\n", code[0][aa], code[1][ba], code[2][ca]);
			if (l==0 || l==len-1) continue;
			printf("PAIR 1 = %d %d  %f\n", aa,ba, pairs[0][1][blink.a].s);
			printf("PAIR 2 = %d %d  %f\n", ba,ca, pairs[1][2][blink.b].s);
			printf("PAIR 3 = %d %d  %f\n", ca,aa, pairs[0][2][blink.c].s);
		}
		Pr(blink.s) NL NL
	}
}

void linkup(Pairs ***pairs, int **np)
{ // NB: a < b
int	a, b, c, n = 0;
float	s, smin = 99999;
int	ni = np[0][1];
	FOR(i,ni) // first pair
	{ Pairs *pi = pairs[0][1];
	  int	ai = pi[i].a, bi = pi[i].b;
	  float si = pi[i].s;
	  int	nj = np[1][2];
		FOR(j,nj) // secnd pair
		{ Pairs *pj = pairs[1][2];
	  	  int	aj = pj[j].a, bj = pj[j].b;
		  float sj = pj[j].s;
		  int	nk = np[0][2];
			if (bi != aj) continue;
			FOR(k,nk) // third pair
			{ Pairs *pk = pairs[0][2];
	  		  int	ak = pk[k].b, bk = pk[k].a;
		 	  float sk = pk[k].s;
				if (bj != ak) continue;
				if (bk != ai) continue;
				n++;
				s = si+sj+sk;
				// printf("%d %d - %d %d - %d %d = %f\n", ai,bi,aj,bj,ak,bk, s);
				if (s > smin) continue;
				a=i; b=j; c=k; smin=s;
			}
		}
	}
	Pi(a) Pi(b) Pi(c) Pr(smin) NL
	blink.a=a; blink.b=b; blink.c=c;
	blink.s=smin;
	Pi(n) Pt(circuits) NL
}

float seqd ( char **seqs, int i, int j, int len ) {
float	score = 0;
	FOR(l,len) {
		if (seqs[i][l]=='-') continue;	
		if (seqs[j][l]=='-') continue;	
		if (seqs[i][l]==seqs[j][l]) score += 1.0;	
	}
	//Pi(i) Pi(j) Pr(score) NL
	return score;
}

void trace ( Path *path, int row, int **pat, int n, int run )
{
	if (run==0) return;
	if ( pat[0][0]<0 ) return; // flagged as used
	printf("%d ", row);
	if (run>0) { path->away[path->a] = row; path->a++; }
	if (run<0) { path->back[path->b] = row; path->b++; }
	if (row == n-1) { // start of return path
		NL printf(" HTAP %d ", n-1);
		path->back[0] = n-1; path->b = 1;
		FOR(i,n-1) { pat[i][0] = 999; } // reset for return
		run = -1; // flag on return path
	}
	FIR(i,n-1) { int p = pat[row][i]; // loop from 1 (0=flag)
		if ( pat[p][0] < 0 ) continue; // flagged as used
		pat[p][0] = -1;
		if (run<0 && p==0) { // home
			printf("%d ", p);
			path->back[path->b] = 0; path->b++;
			run = 0;
			return;
		}
		trace(path,p,pat,n,run);
	}
}
