/*
c++ tripdist.cpp -o tripdist sims/util.o -lm

reads dists[123].dat and finds best pairings
*/

#include "sims/util.hpp"

float pairups ( float***, int, int, int, Pairs* );
int min3 ( int, int, int );

int main (int argc, char** argv) {
char	line[999];
FILE	*dat;
float	**mat[3], **sat[3], ***dif, score;
Pairs	*pairs;
int	m,n, n0,n1,n2, nseq[3], nout;
long	seed = (long)time(0);
	srand48(seed);
	sscanf(argv[1],"%d", &nout);	// number of out groups (<nout> before + <nout> after)
	m = nout*2;
	Pi(m) Pt(outgroups) NL NL
	FOR(k,3) { // read dmat for each block
		sprintf(line,"dists%d.dat", k+1);
		dat = fopen(line,"r");
		read_line(dat,line); sscanf(line,"%d", &n);
		Pi(k) Pi(n) NL
		nseq[k] = n;
		mat[k] = new float*[n];
		FOR(i,n) {
			mat[k][i] = new float[n];
			FOR(j,n) 
			{ int	a,b; float d,w;
			  int	io = read_line(dat,line);
				if (io <= 0) {
					Pt(Too few distances for) Pi(k) Pi(n) NL
					exit(1);
				}
				sscanf(line,"%d %d %f %f", &a,&b, &d,&w);
				if (a!=i || b!=j) { Pt(Mismatch) Pi(i) Pi(j) Pi(a) Pi(b) NL exit(1); }
				mat[k][i][j] = d;
			}
		}
		fclose(dat);
		FOR(i,n) { FOR(j,n) printf("  %7.3f", mat[k][i][j]); NL } NL
	}
	FOR(k,3) { int p,q;
		// for each block put the out/seq distances into <sat>
		p = 0;
		n = nseq[k];
		Pi(k) Pi(n) NL
		sat[k] = new float*[n];
		FOR(i,n) {
			if (i<nout || i>=n-nout) continue;
			// for each sequence <p>
			q = 0;
			sat[k][p] = new float[m];
			FOR(j,n) { float d = mat[k][i][j];
				if (j>=nout && j<n-nout) continue;
				// for each outgroup <q>
				printf("%7.3f ", d);
				sat[k][p][q] = d;
				q++;
			} NL
			p++;
		}
	}
	n0 = nseq[0]-m;
	n1 = nseq[1]-m;
	n2 = nseq[2]-m;
	dif = new float**[nseq[0]-m];
	FOR(i,n0) {
		dif[i] = new float*[nseq[1]-m];
		FOR(j,n1) {
			dif[i][j] = new float[nseq[2]-m];
			FOR(k,n2) { float s = 0.0;
				// score each triple of sequences over the outgroups
				FOR(l,m) { float a,b,c;
					a = sat[0][i][l] - sat[1][j][l];
					b = sat[1][j][l] - sat[2][k][l];
					c = sat[2][k][l] - sat[0][i][l];
					s += a*a + b*b + c*c;
				}
				dif[i][j][k] = 200.0 - s;
			}
		}
	}
	n = min3(n0,n1,n2);
	pairs = new Pairs[n];
	pairups(dif,n0,n1,n2,pairs);
	FOR(i,n) {
		printf("TRIPLE  %d %d %d   %f\n", pairs[i].a,pairs[i].b,(int)pairs[i].c, pairs[i].s);
	}
}

// bipartite graph matching

typedef struct {
	int 	a, b, c;
	char	x;
	float	s;
} Triples;

int sort3 ( const void *ac, const void *bc )
{
Triples *a = (Triples*)ac, *b = (Triples*)bc;
        if (a->s > b->s) return -1;
        if (a->s < b->s) return  1;
        return 0;
}

int min3 ( int a, int b, int c ) {
	if (a<=b && a<=c) return a;
	if (b<=c && b<=a) return b;
	if (c<=a && c<=b) return c;
}

float pairups ( float ***m, int n1, int n2, int n3, Pairs *pairs ) 
// good heuristic method for N1xN2xN3 matrices (need not be symmetric)
{
int	n = min3(n1,n2,n3);
Triples	*pair = new Triples[n1*n2*n3];
int	*pick = new int[n];
int	*best = new int[n];
float	score = -99999;
int	k = 0;
Pi(n1) Pi(n2) Pi(n3) NL
	FOR (a,n1) FOR(b,n2) FOR(c,n3) { 
		pair[k].a = a; pair[k].b = b; pair[k].c = c; pair[k].x = ' '; pair[k].s = m[a][b][c]; k++;
	} 
	Pi(k) NL
	qsort(pair,k,sizeof(Triples),sort3); // sort to get big on top
	FOR(i,k-n) { int got; float sum; // loop over starting pairs
		if (pair[i].c == 'x') continue; // already part of a solution
		Pt(start) Pi(i) Pr(pair[i].s) NL 
		pick[0] = i; got = 1;
		FOR(j,k) { int ok = 1; // loop over list of pairs
			FOR(in,got) { // check new j entry against list
				if (pair[pick[in]].a == pair[j].a) ok = 0;
				if (pair[pick[in]].b == pair[j].b) ok = 0;
				if (pair[pick[in]].c == pair[j].c) ok = 0;
			}
			if (ok==0) continue;
			// found a new pair
			pick[got] = j;
			pair[j].x = 'x';
			got++;
			if (got == n) break;
		}
		sum = 0.0;
		FOR(in,got) { int p = pick[in];
			//Pi(in) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
			sum += pair[p].s;
		}
		//Pr(sum) Pr(score) NL
		if (sum > score) { // save best
			score = sum;
			FOR(j,n) best[j] = pick[j];
		}
		//NL
	}
	FOR(i,n) { int p = best[i];
		Pi(i) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
		pairs[i].a = pair[p].a;
		pairs[i].b = pair[p].b;
		pairs[i].c = (char)pair[p].c;
		pairs[i].s = pair[p].s;
	}
	Pr(score) NL
	return score;
}
