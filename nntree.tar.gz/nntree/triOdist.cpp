/*
c++ triOdist.cpp -o triOdist sims/util.o -lm

reads ABC seqs in blocks[123].abc and finds best pairings
*/

#include "sims/util.hpp"

int min3 ( int, int, int );
int max3 ( int, int, int );

float pairups ( float***, int, int, int, Pairs*, int );
int min3 ( int, int, int );

int main (int argc, char** argv) {
int	got;
FILE	*dat;
Pairs	*pairs;
int	*sid[3];
float	sigma, noise;
char	line[9999], **abc[3];
float	**mat[3], **sat[3], ***dif, score;
int	m,n, n0,n1,n2, len, nseq[3], nout, nnout;
long	seed = (long)time(0);
	sscanf(argv[1],"%d", &nout);	// number of outgroups (<nout> before + <nout> after)
	sscanf(argv[2],"%f", &sigma);	// Gaussian spread for character match
	sscanf(argv[3],"%f", &noise);	// Noise added to triple scores
	sscanf(argv[4],"%d", &n);	// Noise factor (run No) and seed help
	srand48(seed+n);
	sigma *= drand48();
	noise *= (float)n;
	if (noise > 10.0) noise *= drand48();
	nnout = nout*2;
	Pi(nnout) Pt(outgroups) Pr(sigma) Pr(noise) NL NL
	FOR(k,3) { // read ABC seqs for each block (Phylip format)
		sprintf(line,"block%d.abc", k+1);
		dat = fopen(line,"r");
		read_line(dat,line); sscanf(line,"%d %d", &n, &len);
		Pi(k) Pi(n) Pi(len) NL
		nseq[k] = n;
		mat[k] = new float*[n];
		abc[k] = new char*[n];
		sid[k] = new int[n];
		FOR(i,n) { int	io = read_line(dat,line);
			mat[k][i] = new float[n];
			abc[k][i] = new char[len+1];
			if (io <= 0) {
				Pt(Too few sequences for) Pi(k) Pi(n) NL
				exit(1);
			}
			strcpy(abc[k][i],line+10);
			line[8] = (char)0;
			sscanf(line+4,"%d", sid[k]+i);
			sid[k][i] -= 100;
		}
		fclose(dat);
	}
	n0 = nseq[0];
	n1 = nseq[1];
	n2 = nseq[2];
	// loop over all triples of ABC seqs from each block and fill <dif[][][]>
	dif = new float**[n0];
	FOR(i,n0) {
		dif[i] = new float*[n1];
		FOR(j,n1) { float sa,sb,sc;
			dif[i][j] = new float[n2];
			FOR(k,n2) { float s = 0.0;
				FOR(l,len) { float a,b,c;
					a = (float)((int)(abc[0][i][l]-'A') - (int)(abc[1][j][l]-'A'));
					b = (float)((int)(abc[1][j][l]-'A') - (int)(abc[2][k][l]-'A'));
					c = (float)((int)(abc[2][k][l]-'A') - (int)(abc[0][i][l]-'A'));
					s += exp(-a*a*sigma) + exp(-b*b*sigma) + exp(-c*c*sigma);
				}
				dif[i][j][k] = s + drand48()*noise;
			}
		}
	}
	n = min3(n0,n1,n2);
	pairs = new Pairs[n];
	pairups(dif,n0,n1,n2,pairs,nnout);
	got = 0;
	FOR(i,n) { int a = pairs[i].a, b = pairs[i].b, c = (int)pairs[i].c;
		if ( a!=b || b!=c ) continue;
		if ( a >= nnout ) continue;
		if ( b >= nnout ) continue;
		if ( c >= nnout ) continue;
		printf("Triple  %d %d %d   %f\n", a,b,c, pairs[i].s);
		got++;
	}
	Pi(got) NL NL
	if (got < nout*2) exit(1);
	// write triples with original Phylip code (Seq-000/Out-000) to match block[123].code order
	FOR(i,n) { int a = pairs[i].a, b = pairs[i].b, c = (int)pairs[i].c;
		//printf("Triple  %d %d %d   %f\n", a, b, c, pairs[i].s);
		printf("TRIPLE  %d %d %d   %f\n", sid[0][a], sid[1][b], sid[2][c], pairs[i].s);
	} NL
}

// tripartite graph matching

typedef struct {
	int 	a, b, c;
	char	x;
	float	s;
} Triples;

int sort3 ( const void *ac, const void *bc )
{
Triples *a = (Triples*)ac, *b = (Triples*)bc;
        if (a->s > b->s) return -1;
        if (a->s < b->s) return  1;
        return 0;
}

int max3 ( int a, int b, int c ) {
	if (a>=b && a>=c) return a;
	if (b>=c && b>=a) return b;
	if (c>=a && c>=b) return c;
}

int min3 ( int a, int b, int c ) {
	if (a<=b && a<=c) return a;
	if (b<=c && b<=a) return b;
	if (c<=a && c<=b) return c;
}

float pairups ( float ***m, int n1, int n2, int n3, Pairs *pairs, int nout ) 
// good heuristic method for N1xN2xN3 matrices (need not be symmetric)
{
int	n = min3(n1,n2,n3);
Triples	*pair = new Triples[n1*n2*n3];
int	*pick = new int[n];
int	*best = new int[n];
float	score = -99999;
int	k = 0;
	Pi(n1) Pi(n2) Pi(n3) NL
	FOR (a,n1) FOR(b,n2) FOR(c,n3) { 
		pair[k].a = a; pair[k].b = b; pair[k].c = c; pair[k].x = ' '; pair[k].s = m[a][b][c]; k++;
	} 
	Pi(k) NL
	qsort(pair,k,sizeof(Triples),sort3); // sort to get big on top
	FOR(i,k-n) { int got; float sum; // loop over starting pairs
		if (pair[i].c == 'x') continue; // already part of a solution
		//Pt(start) Pi(i) Pr(pair[i].s) NL 
		pick[0] = i; got = 1;
		FOR(j,k) { int ok = 1; // loop over list of pairs
			FOR(in,got) { // check new j entry against list
				if (pair[pick[in]].a == pair[j].a) ok = 0;
				if (pair[pick[in]].b == pair[j].b) ok = 0;
				if (pair[pick[in]].c == pair[j].c) ok = 0;
			}
			if (ok==0) continue;
			// found a new pair
			pick[got] = j;
			pair[j].x = 'x';
			got++;
			if (got == n) break;
		}
		sum = 0.0;
		FOR(in,got) { int p = pick[in];
			//Pi(in) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
			sum += pair[p].s;
		}
		//Pr(sum) Pr(score) NL
		if (sum > score) { int got = 0;// save best
			FOR(j,n) { // check all outgroups are onboard (outgroups at top)
				if (pair[pick[j]].a < nout) got++;
				if (pair[pick[j]].b < nout) got++;
				if (pair[pick[j]].c < nout) got++;
			}
			if (got == nout*3) { // save
				FOR(j,n) best[j] = pick[j];
				score = sum;
			}
		}
		//NL
	}
	if (score < 0.0) { Pr(score) NL exit(1); }
	FOR(i,n) { int p = best[i];
		Pi(i) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
		pairs[i].a = pair[p].a;
		pairs[i].b = pair[p].b;
		pairs[i].c = (char)pair[p].c;
		pairs[i].s = pair[p].s;
	}
	Pr(score) NL
	return score;
}
