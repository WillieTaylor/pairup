/*
c++ rescale.cpp -o rescale sims/util.o -lm

1 = nout = number of +/- outgroups

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
char	line[9999];
FILE	*dat;
float	**dout, score;
int	m,n, nseq,nout;
	sscanf(argv[1],"%d", &nout);
	Pi(nout) NL NL
	dout = new float*[3];
	FOR(i,3) dout[i] = new float[nout*nout*2];
	FOR(i,3) // read seq. distances for each block of paralogs (with outgroups at 0,1,.. and ...,n-2,n-1)
	{ float **mat, dave;
		sprintf(line,"block%d.dat", i+1);
		dat = fopen(line,"r");
		read_line(dat,line);
		sscanf(line,"%d", &n);
		mat = new float*[n];
		FOR(j,n) { int io;
			mat[j] = new float[n];
			FOR(k,n) { float d;
				io = read_line(dat,line);
				if (io <= 0 ) break;
				sscanf(line,"%f", &d);
				mat[j][k] = d;
			}
			if (io <= 0 ) break;
		}
		fclose(dat);
		// rescale distances to inter-outgroup average
		m = 0;
		dave = 0.0;
		FOR(j,n) {
			FOR(k,n) { float d = mat[j][k];
				if (mat[j][k] != mat[j][k]) {
					Pt(Dist matrix is not symmetric)
					Pi(i) Pi(j) Pi(k) Pr(mat[j][k]) Pr(mat[j][k]) NL
					exit(1);
				}
				if (j==k && d!=0.0) {
					Pt(Dist matrix diagonal is not zero)
					Pi(i) Pi(j) Pr(mat[j][k]) NL
					exit(1);
				}
				if (k>=j) continue;
				if (j>=nout && j<n-nout) continue;
				if (k>=nout && k<n-nout) continue;
				// for just outgroup pairs take average (dave) and store differences (dout)
				dave += d;
				dout[i][m] = d;
				m++;
			}
		}
		// take average over the <m> pairs
		dave /= (float)m;
		// rescale all distances and print in format for project() and pairdist() = i j d w
		sprintf(line,"dists%d.dat", i+1);
		dat = fopen(line,"w");
		fprintf(dat,"%5d\n", n);
		FOR(j,n) { float d, w=1.0;
			FOR(k,n) { // set the scale of the outgroups average to 10
				d = 10.0*mat[j][k]/dave;
				mat[j][k] = d;
				printf("%5.1f ", d);
				fprintf(dat,"%5d %5d   %f %f\n", j,k, d,w);
			} NL
		} NL
		fclose(dat);
	}
	// <dout> holds the distance between outgroups
	score = 0.0;
	FOR(i,m) { float d; 
		d = dout[0][i] - dout[1][i]; score += d*d;
		d = dout[1][i] - dout[2][i]; score += d*d;
		d = dout[0][i] - dout[2][i]; score += d*d;
	}
	score = sqrt(score/(m*3));
	// <score> is the RMSD between equivalent outgroup pairs
	Pr(score) NL
	// the score is used to find similar outgroups to use for matching in matchup()
}
