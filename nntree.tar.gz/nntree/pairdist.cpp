/*
c++ pairdist.cpp -o pairdist sims/util.o -lm

reads trees[123].dat and finds best pairings
copies treedist.csh I/O calculating distances between all pairs of dist matrices etween blocks

home/pairdist 1 2 0 $seqs $nout $ntrees | grep '^P ' > count0.dat
      blocks--^-^ ^--countN.dat
*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
char	line[999];
FILE	*dat;
float	**mat[3], ***matA, ***matB, **sat[3], **dpq, score;
int	**sum, **pat[3], pair;
Pairs	*pairs[3];
int	a,b,c, m,n, nn, nout, nmats, io, na, nb;
long	seed = (long)time(0);
	srand48(seed);
	sscanf(argv[1],"%d", &a);	// block A
	sscanf(argv[2],"%d", &b);	// block B
	sscanf(argv[3],"%d", &c);	// output (countC.dat)
	sscanf(argv[4],"%d", &n);	// total number of sequences
	sscanf(argv[5],"%d", &nout);	// number of out groups (<nout> before + <nout> after)
	sscanf(argv[6],"%d", &nmats);	// number of randomised matrices from neighbor.csh
	Pi(nmats) NL
	Pt(Blocks) Pi(a) Pi(b) NL
	Pi(n) Pt(sequences) Pi(nout*2) Pt(outgroups) NL 
	matA = new float**[nmats];
	matB = new float**[nmats];
	FOR(i,nmats) {
		matA[i] = new float*[n];
		matB[i] = new float*[n];
		FOR(j,n) {
			matA[i][j] = new float[n];
			matB[i][j] = new float[n];
		}
	}
	sprintf(line,"tree%d.dat", a);
	dat = fopen(line,"r");
	FOR(i,nmats) { // read randomised pairwise distances for block A
		Pt(A) Pi(i) NL
		read_line(dat,line);
		sscanf(line,"%d", &na);
		if ( na != n ) { Pt(Seq num diff for A) Pi(na) Pi(n) NL exit(1); }
		FOR(j,n) {
			io = read_line(dat,line);
			Ps(line) NL
			if (io <= 0) break;
			FOR(k,n) sscanf(line+(k+1)*10,"%f", matA[i][j]+k);
		}
		FOR(j,n) { FOR(k,n) matA[i][j][k] = matA[i][k][j]; }
		FOR(j,n) { FOR(k,n) printf("  %5.3f", matA[i][j][k]); NL } NL
		if (io <= 0) break;
	}
	fclose(dat);
	NL
	sprintf(line,"tree%d.dat", b);
	dat = fopen(line,"r");
	FOR(i,nmats) { // read randomised pairwise distances for block A
		Pt(B) Pi(i) NL
		read_line(dat,line);
		sscanf(line,"%d", &nb);
		if ( nb != n ) { Pt(Seq num diff for B) Pi(nb) Pi(n) NL exit(1); }
		FOR(j,n) {
			io = read_line(dat,line);
			Ps(line) NL
			if (io <= 0) break;
			FOR(k,n) sscanf(line+(k+1)*10,"%f", matB[i][j]+k);
		}
		FOR(j,n) { FOR(k,n) matB[i][j][k] = matB[i][k][j]; }
		FOR(j,n) { FOR(k,n) printf("  %5.3f", matB[i][j][k]); NL } NL
		if (io <= 0) break;
	}
	fclose(dat);
	NL
	FOR(k,3) {
		sat[k] = new float*[n];
		pat[k] = new int*[n];
		FOR(j,n) {
			sat[k][j] = new float[n];	// seqXout distances
			pat[k][j] = new int[n];	// rank after sort()
		}
		pairs[k] = new Pairs[n];	// pairs from matchup()
	}
	// seqXseq work array
	dpq = new float*[n]; FOR(i,n) dpq[i] = new float[n];
	sum = new int*[n];
	FOR(i,n) {
		sum[i] = new int[n];
		FOR(j,n) sum[i][j] = 0;
	}
	FOR(ma,nmats) FOR(mb,nmats) {
		mat[0] = matA[ma]; mat[1] = matB[mb];
		NL Pi(ma) Pi(mb) NL
		FOR(k,2) { int p,q; // using old code from NJTree to hold the two matrices
			// for each block (A,B = 0,1) put the out/seq distances into <sat>
			Pi(k) NL
			p = 0;
			FOR(i,n) {
				if (i<nout || i>=n-nout) continue;
				// for each sequence <p>
				q = 0;
				FOR(j,n) { float d = mat[k][i][j];
					if (j>=nout && j<n-nout) continue;
					// for each outgroup <q>
					printf("%7.3f ", d);
					sat[k][p][q] = d;
					q++;
				} NL
				sort(sat[k][p],pat[k][p],-q); // reverse sort outgroups for seq <p>
				p++;
			} NL
		}
		nn = nout*2;
		m = n - nn; // number of core sequences
		Pt(Rank of outgroup N for sequence i) NL
		FOR(i,m) { // for each core sequence
			Pi(i) NL
			FOR(j,2) { // compare outgroup order over each block
				FOR(k,nn) printf("%3d", pat[j][i][k]); NL
			} NL
		}
		// for each pair of rank+dist sets ([p+s]at[]s) score protein pairs
		Pt(score block pairs) NL
		score = 0.0;
		FOR(pair,1) { int p,q; float s; // using old NJTree code: <pair> is only 0 here
			// for each pair of blocks (p and q)
			if (pair==0) { p=0; q=1; }
			if (pair==1) { p=1; q=2; }
			if (pair==2) { p=2; q=0; }
			NL Pt(Blocks) Pi(p) Pi(q) NL
			FOR(i,m) { FOR(j,m) {
				// for each pair of sequences i,j
				s = 0.0;
				FOR(k,nn) { int dr; float ds, w;
				 	// sum d over all outgroups k
					dr = pat[p][i][k] - pat[q][j][k]; // rank dif
					ds = sat[p][i][k] - sat[q][j][k]; // dist dif
					ds *= ds; dr *= dr;
					w = exp(-sat[p][i][k]*sat[q][j][k]*0.005);
					//ds /= (sat[p][i][k]+sat[q][j][k]); // weight by inverse length 
					//s += 0.1*ds*w + (float)dr;
					//s += ds*w + (float)dr;
					s += ds;
				}
				//dpq[i][j] =  1.0/(1.0+sqrt(s/(float)(m*m)));
				dpq[i][j] = 10*exp(-s*0.5); 
				printf("%7.3f ", dpq[i][j]);
			} NL } NL
			s = 0.0;
			pairup(dpq,m,pairs[pair]);
			n = 0;
			FOR(k,nout) { sum[n][n]++; n++; }
			FOR(k,m) { int a = pairs[pair][k].a+nout; b = pairs[pair][k].b+nout;
				Pi(a) Pi(b) Pr(pairs[pair][k].s) NL
				s += pairs[pair][k].s;
				sum[a][b]++;
				n++;
			}
			FOR(k,nout) { sum[n][n]++; n++; }
			score += s;
		}
	}
	FOR(i,n) {
		FOR(j,n) printf("P %2d %2d %2d  %d\n", c,i,j,sum[i][j]);
	}
}
