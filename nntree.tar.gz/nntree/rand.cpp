/*
c++ rand.cpp -o rand sims/util.o -lm

./rand (int)seed-helper (int)number-out (float)value-range

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
int    n;
float    r;  // if -ve write an int
long    seed = (long)time(0);
        sscanf(argv[1],"%d", &n); // seed helper (if recalled in under 1sec)
    seed += n;
    srand48(seed);
        sscanf(argv[2],"%d", &n); // number to generate
        sscanf(argv[3],"%f", &r); // range
    if ( r < 0.0) FOR(i,n) printf(" %d", (int)(-r*drand48()+0.5));
        else  FOR(i,n) printf(" %f", r*drand48());
    NL
}
