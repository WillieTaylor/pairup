/*
c++ pairup.cpp -o pairup  sims/util.o -lm

reads counts.dat and finds best pairings
(equivalent to matchup.cpp)

*/

#include "sims/util.hpp"

int main (int argc, char** argv) {
char	line[99];
FILE	*dat;
float	**mat[3], **sat[3], **sum[3], score, s;
int	**pat[3], pair;
Pairs	*pairs[3];
int	m, n, mm, nn, nout, tries;
long	seed = (long)time(0);
	srand48(seed);
	sscanf(argv[1],"%d", &n);	// total number of sequences
	sscanf(argv[2],"%d", &nout);	// number of out groups (<nout> before + <nout> after)
	sscanf(argv[3],"%d", &tries);	// random tries
	Pi(n) Pt(sequences) Pi(nout*2) Pt(outgroups) NL 
	nn = nout*2;
	FOR(i,3) {
		mat[i] = new float*[n];
		FOR(j,n) {
			mat[i][j] = new float[n];
			FOR(k,n) mat[i][j][k] = 0.0;
		}
	}
	dat = fopen("counts.dat","r");
	while (1) // read pairwise counts
	{ int   a,b,c,d,
		io = read_line(dat,line);
		if (io <= 0) break;
		sscanf(line,"%d %d %d %d", &a, &b, &c, &d);
		mat[a][b][c] = (float)d;
		// counts are not symmetric so keep highest (ie non-zero)
	}
	NL
	m = n - nn; // number of seqs
	FOR(k,3) {
		sum[k] = new float*[m];
		sat[k] = new float*[m];
		pat[k] = new int*[m];
		FOR(j,m) {
			sum[k][j] = new float[m];	// seqXseq sums
			sat[k][j] = new float[nn];	// seqXout distances
			pat[k][j] = new int[nn];	// rank after sort()
			FOR(i,m) sum[k][j][i] = 0.0;
		}
		pairs[k] = new Pairs[m];	// pairs from matchup()
	}
	// seqXseq work array
	FOR(shake,tries) { // randomised tries (maybe a small shake may hit a cyclic braid)
		score = 0.0;
		Pt(----------------------------) NL
		Pi(shake) NL NL
		FOR(k,3) { int p,q; float s, t, d = mat[k][0][0]/100.0; // 0,0 holds total counts (from 1st outgroup)
			// for each block put the seq/seq distances (+rand) into <sat>
			t = 0.0;
			p = 0;
			FOR(i,n) {
				if (i<nout || i>=n-nout) continue;
				// for each sequence <p>
				q = 0;
				FOR(j,n) {
					if (j<nout || j>=n-nout) continue;
					// for each sequence <q>
					sat[k][p][q] = mat[k][i][j] + d*drand48();
					printf("%8.3f ", sat[k][p][q]);
					t += sat[k][p][q];
					q++;
				} NL
				p++;
			} NL
			s = 0.0;
			pairup(sat[k],m,pairs[k]);
			FOR(i,m) { int a = pairs[k][i].a, b = pairs[k][i].b;
				Pi(a) Pi(b) Pr(pairs[k][i].s) NL
				s += pairs[k][i].s;
			}
			NL
			s /= t; // score of selected pairs normalised by total score
			FOR(i,m) pairs[k][i].s *= s; // applied to selections
			score += s;
		}
		Pt(Normalised) Pr(score) NL
		NL
		Pt(Individual) NL
		FOR(i,m)
		{ int	a0 =  pairs[0][i].a, b0 = pairs[0][i].b,
			a1 =  pairs[1][i].a, b1 = pairs[1][i].b,
			a2 =  pairs[2][i].a, b2 = pairs[2][i].b;
			printf(" %d %d - %d %d - %d %d\n", a0,b0,a1,b1,a2,b2);
		} NL
		// trace path and accumulate pairs in sum for consensus
		FOR(k,3) FOR(i,m) FOR(j,m) sum[k][i][j] = 0.0;
		Pt(Chainned) NL
		FOR(i,m) // for each A-B link
		{ int	a0 =  pairs[0][i].a, b0 = pairs[0][i].b;
			FOR(j,m) // for each B-C link
			{ int	a1 =  pairs[1][j].a, b1 = pairs[1][j].b;
				if (b0 != a1) continue;
				FOR(k,m) // for each C-A link
				{ int	a2 =  pairs[2][k].a, b2 = pairs[2][k].b;
					if (b1 != a2) continue;
					if (a0==b2) s = 10.0; else s = 0.1; // bonus for cyclic
					sum[0][a0][b0] += pairs[0][i].s * s;
					sum[1][a1][b1] += pairs[1][j].s * s;
					sum[2][a2][b2] += pairs[2][k].s * s;
					printf(" %d %d = %d %d = %d %d ", a0,b0,a1,b1,a2,b2);
					if (s > 1.0) Pt(cyclic) NL
				}
			}
		}
	}
	NL
	Pt(============================) NL
	Pt(Summed pairs) NL
	FOR(k,3) { NL
		if (k==0) { Pt(Blocks 0+1) NL }
		if (k==1) { Pt(Blocks 1+2) NL }
		if (k==2) { Pt(Blocks 2+0) NL }
		FOR(i,m) {
			FOR(j,m) printf("%7.3f ", sum[k][i][j]/(float)tries); NL
		}
		score = 0.0;
		pairup(sum[k],m,pairs[k]);
		if (k==0) Pt(SUM 0+1)
		if (k==1) Pt(SUM 1+2)
		if (k==2) Pt(SUM 2+0)
		FOR(i,m) { int a = pairs[k][i].a, b = pairs[k][i].b;
			printf("%2d =%2d  ", a,b);
			score += pairs[k][i].s;
		}
		score *= 0.01;
		Pr(score) NL 
	} NL
}
