/*
c++ triodist.cpp -o triodist sims/util.o -lm

reads ABC seqs in blocks[123].abc and finds best pairings
*/

#include "sims/util.hpp"

int min3 ( int, int, int );
int max3 ( int, int, int );

float pairups ( float***, int, int, int, Pairs* );
int min3 ( int, int, int );

int main (int argc, char** argv) {
int	got;
float	noise;
char	line[999];
char	**abc[3];
FILE	*dat;
float	**mat[3], **sat[3], ***dif, score;
Pairs	*pair[3], *pairs;
int	m,n, nn, n0,n1,n2, m0,m1,m2, len, nseq[3], nout;
long	seed = (long)time(0);
	srand48(seed);
	sscanf(argv[1],"%d", &nout);	// number of outgroups (<nout> before + <nout> after)
	sscanf(argv[2],"%f", &noise);
	Pi(nout) Pt(double outgroups) Pr(noise) NL NL
	FOR(k,3) { // read ABC seqs for each block (Phylip format)
		sprintf(line,"block%d.abc", k+1);
		dat = fopen(line,"r");
		read_line(dat,line); sscanf(line,"%d %d", &n, &len);
		Pi(k) Pi(n) Pi(len) NL
		nseq[k] = n;
		mat[k] = new float*[n];
		abc[k] = new char*[len];
		FOR(i,n) { int	io = read_line(dat,line);
			mat[k][i] = new float[n];
			abc[k][i] = new char[len+1];
			if (io <= 0) {
				Pt(Too few sequences for) Pi(k) Pi(n) NL
				exit(1);
			}
			strcpy(abc[k][i],line+10);
		}
		fclose(dat);
	}
	FOR(k,3) { // collect pairs within each block <k>
		n = nseq[k]; m = (n*n-n)/2;
		pair[k] = new Pairs[m];
		nn = 0;
		FOR(i,n) FOR(j,n) { float sum = 0.0;
			mat[k][i][j] = 0.0;
			if (i>=j) continue;
			FOR(l,len) { float d, s = 0.1;
				d = (float)((int)(abc[k][i][l]-'A') - (int)(abc[k][j][l]-'A'));
				sum += exp(-d*d*s);
			}
			pair[k][nn].a = i;
			pair[k][nn].b = j;
			pair[k][nn].s = 10.0*sum/(float)len;
			nn++;
		}
	}
	// loop over all triples of pais of ABC seqs from each block and fill <dif[][][]>
	n0 = nseq[0]; m0 = (n0*n0-n0)/2;
	n1 = nseq[1]; m1 = (n1*n1-n1)/2;
	n2 = nseq[2]; m2 = (n2*n2-n2)/2;
	dif = new float**[m0];
	FOR(i,m0) {
		dif[i] = new float*[m1];
		FOR(j,m1) { float sa,sb,sc;
			dif[i][j] = new float[m2];
			FOR(k,m2) { float a,b,c, d, s = 0.1;
				a = pair[0][i].s - pair[1][j].s;
				b = pair[1][j].s - pair[2][k].s;
				c = pair[2][k].s - pair[0][i].s;
				d = exp(-a*a*s) + exp(-b*b*s) + exp(-c*c*s);
				dif[i][j][k] = 10.0*d + drand48()*noise;
			}
		}
	}
	m = min3(m0,m1,m2);
	pairs = new Pairs[m];
	pairups(dif,m0,m1,m2,pairs);
	FOR(i,m)
	{ float	s = pairs[i].s;
	  int	a = pairs[i].a, b = pairs[i].b, c = (int)pairs[i].c,
		a0 = pair[0][a].a, b0 = pair[0][a].b, 
		a1 = pair[1][b].a, b1 = pair[1][b].b, 
		a2 = pair[2][c].a, b2 = pair[2][c].b; 
		if (s < NOISE) break;
		printf("TRIPLE  %d+%d  %d+%d  %d+%d   %f\n", a0,b0, a1,b1, a2,b2, s);
	} NL
/*
	got = 0;
	FOR(i,n) { int a = pairs[i].a, b = pairs[i].b, c = (int)pairs[i].c;
		if ( a!=b || b!=c ) continue;
		if ( a>=nout && a<n-nout ) continue;
		if ( b>=nout && b<n-nout ) continue;
		if ( c>=nout && c<n-nout ) continue;
		printf("TRIPLEs  %d %d %d   %f\n", pairs[i].a,pairs[i].b,(int)pairs[i].c, pairs[i].s);
		got++;
	} NL
	Pi(got) NL
*/
}

// tripartite graph matching

typedef struct {
	int 	a, b, c;
	char	x;
	float	s;
} Triples;

int sort3 ( const void *ac, const void *bc )
{
Triples *a = (Triples*)ac, *b = (Triples*)bc;
        if (a->s > b->s) return -1;
        if (a->s < b->s) return  1;
        return 0;
}

int max3 ( int a, int b, int c ) {
	if (a>=b && a>=c) return a;
	if (b>=c && b>=a) return b;
	if (c>=a && c>=b) return c;
}

int min3 ( int a, int b, int c ) {
	if (a<=b && a<=c) return a;
	if (b<=c && b<=a) return b;
	if (c<=a && c<=b) return c;
}

float pairups ( float ***m, int n1, int n2, int n3, Pairs *pairs ) 
// good heuristic method for N1xN2xN3 matrices (need not be symmetric)
{
int	n = min3(n1,n2,n3);
Triples	*pair = new Triples[n1*n2*n3];
int	*pick = new int[n];
int	*best = new int[n];
float	score = -99999;
int	maxk = 10000, k = 0;
int	got;
	Pi(n1) Pi(n2) Pi(n3) NL
	FOR (a,n1) FOR(b,n2) FOR(c,n3) { 
		pair[k].a = a; pair[k].b = b; pair[k].c = c; pair[k].x = ' '; pair[k].s = m[a][b][c]; k++;
	} 
	Pi(k) NL
	qsort(pair,k,sizeof(Triples),sort3); // sort to get big on top
	if (k-n > maxk) k = maxk;
	FOR(i,k-n) { float sum; // loop over starting pairs
		if (pair[i].c == 'x') continue; // already part of a solution
		//Pt(start) Pi(i) Pr(pair[i].s) NL 
		pick[0] = i; got = 1;
		FOR(j,k) { int ok = 1; // loop over list of pairs
			FOR(in,got) { // check new j entry against list
				if (pair[pick[in]].a == pair[j].a) ok = 0;
				if (pair[pick[in]].b == pair[j].b) ok = 0;
				if (pair[pick[in]].c == pair[j].c) ok = 0;
			}
			if (ok==0) continue;
			// found a new pair
			pick[got] = j;
			pair[j].x = 'x';
			got++;
			if (got == n) break;
		}
		sum = 0.0;
		FOR(in,got) { int p = pick[in];
			//Pi(in) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
			sum += pair[p].s;
		}
		//Pr(sum) Pr(score) NL
		if (sum > score) { // save best
			score = sum;
			FOR(j,n) best[j] = pick[j];
		}
		//NL
	}
	Pi(got) Pi(n) NL
	FOR(i,got) { int p = best[i];
		Pi(i) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
		pairs[i].a = pair[p].a;
		pairs[i].b = pair[p].b;
		pairs[i].c = (char)pair[p].c;
		pairs[i].s = pair[p].s;
	}
	Pr(score) NL
	return score;
}
