/*
c++ tricount.cpp -o tricountZZims/util.o -lm

reads counts of triples and finds best pairings
*/

#include "sims/util.hpp"

typedef struct {
	int 	a, b, c;
	char	x;
	float	s;
} Triples;

int min3 ( int, int, int );
int max3 ( int, int, int );

float pairups ( Triples*, int, int, Pairs* );
int min3 ( int, int, int );

int main (int argc, char** argv) {
char	line[999];
int	min, n = 0;
FILE	*dat;
Pairs	*pairs;
Triples	*trips = new Triples[9999];
	sscanf(argv[1],"%d", &min);
	dat = fopen("triple.count.sort","r");
	DO{ int a,b,c,d, io = read_line(dat,line);
		if (io <= 0) break;
		sscanf(line,"%d %d %d  %d", &a,&b,&c, &d);
		trips[n].a = a;
		trips[n].b = b;
		trips[n].c = c;
		trips[n].s = (float)d;
		n++;
	}
	Pi(n) NL
	pairs = new Pairs[n];
	pairups(trips,n,min,pairs);
	FOR(i,n) {
		if (pairs[i].s < NOISE) break;
		printf("TRIPLE  %d %d %d   %f\n", pairs[i].a,pairs[i].b,(int)pairs[i].c, pairs[i].s);
	} NL
/*
	got = 0;
	FOR(i,n) { int a = pairs[i].a, b = pairs[i].b, c = (int)pairs[i].c;
		if ( a!=b || b!=c ) continue;
		if ( a>=nout && a<n-nout ) continue;
		if ( b>=nout && b<n-nout ) continue;
		if ( c>=nout && c<n-nout ) continue;
		printf("TRIPLE  %d %d %d   %f\n", pairs[i].a,pairs[i].b,(int)pairs[i].c, pairs[i].s);
		got++;
	} NL
	Pi(got) NL
*/
}

// tripartite graph matching

int sort3 ( const void *ac, const void *bc )
{
Triples *a = (Triples*)ac, *b = (Triples*)bc;
        if (a->s > b->s) return -1;
        if (a->s < b->s) return  1;
        return 0;
}

int max3 ( int a, int b, int c ) {
	if (a>=b && a>=c) return a;
	if (b>=c && b>=a) return b;
	if (c>=a && c>=b) return c;
}

int min3 ( int a, int b, int c ) {
	if (a<=b && a<=c) return a;
	if (b<=c && b<=a) return b;
	if (c<=a && c<=b) return c;
}

float pairups ( Triples *pair, int k, int n, Pairs *pairs ) 
{
int	*pick = new int[k];
int	*best = new int[k];
float	score = -99999;
int	got;
/*
int	k = 0;
	Pi(n1) Pi(n2) Pi(n3) NL
	FOR (a,n1) FOR(b,n2) FOR(c,n3) { 
		pair[k].a = a; pair[k].b = b; pair[k].c = c; pair[k].x = ' '; pair[k].s = m[a][b][c]; k++;
	} */
	qsort(pair,k,sizeof(Triples),sort3); // sort to get big on top
	FOR(i,k-1) { float sum; // loop over starting pairs
		if (pair[i].c == 'x') continue; // already part of a solution
		//Pt(start) Pi(i) Pr(pair[i].s) NL 
		pick[0] = i; got = 1;
		FOR(j,k) { int ok = 1; // loop over list of pairs
			FOR(in,got) { // check new j entry against list
				if (pair[pick[in]].a == pair[j].a) ok = 0;
				if (pair[pick[in]].b == pair[j].b) ok = 0;
				if (pair[pick[in]].c == pair[j].c) ok = 0;
			}
			if (ok==0) continue;
			// found a new pair
			pick[got] = j;
			pair[j].x = 'x';
			got++;
			if (got == n) break;
		}
		sum = 0.0;
		FOR(in,got) { int p = pick[in];
			//Pi(in) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
			sum += pair[p].s;
		}
		//Pr(sum) Pr(score) NL
		if (sum > score) { // save best
			score = sum;
			FOR(j,n) best[j] = pick[j];
		}
		//NL
	}
	Pi(got) Pi(n) NL
	FOR(i,got) { int p = best[i];
		Pi(i) Pi(p) Pi(pair[p].a) Pi(pair[p].b) Pi(pair[p].c) Pr(pair[p].s) NL
		pairs[i].a = pair[p].a;
		pairs[i].b = pair[p].b;
		pairs[i].c = (char)pair[p].c;
		pairs[i].s = pair[p].s;
	}
	Pr(score) NL
	return score;
}
